package controller;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import model.Tool;
import view.DrawingPanel;


public class ToolAction extends AbstractAction {
    /**
     * default UID.
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * tool.
     */
    private final Tool myTool;
    
    /**
     * drawing panel.
     */
    private final DrawingPanel myDrawingPanel;

    public ToolAction(final String theName, final Tool theTool,
            final DrawingPanel theDrawingPanel) {
        super(theName);
        this.myTool = theTool;
        this.myDrawingPanel = theDrawingPanel;
        putValue(SELECTED_KEY, false);
    }

    @Override
    public void actionPerformed(final ActionEvent theE) {
        myDrawingPanel.setCurrentTool(myTool);
    }
}
