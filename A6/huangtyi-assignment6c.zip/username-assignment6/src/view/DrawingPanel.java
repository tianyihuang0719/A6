package view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import javax.swing.JPanel;
import model.ShapeData;
import model.Tool;


public class DrawingPanel extends JPanel {
    /**
     * default UID.
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * default stroke width.
     */
    private static final float DEFAULT_STROKE_WIDTH = 5.0f;
    
    /**
     * current tool.
     */
    private Tool myCurrentTool;

    /**
     * is drwaing.
     */
    private boolean myIsDrawing;
    
    /**
     * all shapes.
     */
    private final java.util.List<ShapeData> myShapes = new ArrayList<>();
    
    /**
     * current color.
     */
    private Color myCurrentColor = Color.BLACK;

    /**
     * stroke width.
     */
    private float myStrokeWidth = DEFAULT_STROKE_WIDTH;
    
    /**
     * clear observers.
     */
    private final java.util.List<Consumer<Boolean>> myClearObservers = new ArrayList<>();

    public DrawingPanel() {
        setBackground(Color.WHITE);
        setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
        final MouseAdapter mouseAdapter = createApapter();
        addMouseListener(mouseAdapter);
        addMouseMotionListener(mouseAdapter);
    }

    public void setCurrentTool(final Tool theTool) {
        myCurrentTool = theTool;
    }

    public void setCurrentColor(final Color theColor) {
        myCurrentColor = theColor;
    }

    public Color getCurrentColor() {
        return myCurrentColor;
    }

    public void setStrokeWidth(final float theWidth) {
        myStrokeWidth = theWidth;
    }

    public void clear() {
        myShapes.clear();
        repaint();
        notifyClearButtonObservers();
    }

    public void addClearButtonObserver(final Consumer<Boolean> theObserver) {
        myClearObservers.add(theObserver);
        theObserver.accept(!myShapes.isEmpty());
    }

    private void notifyClearButtonObservers() {
        myClearObservers.forEach(observer -> observer.accept(!myShapes.isEmpty()));
    }
    
    private MouseAdapter createApapter() {
        return new MouseAdapter() {
            public void mousePressed(final MouseEvent theE) {
                myCurrentTool.start(theE.getPoint());
                myIsDrawing = true;
            }
            public void mouseDragged(final MouseEvent theE) {
                myCurrentTool.drag(theE.getPoint());
                repaint();
            }
            public void mouseReleased(final MouseEvent theE) {
                if (myIsDrawing) {
                    myShapes.add(new ShapeData(myCurrentTool.getShape(),
                            myCurrentColor, myStrokeWidth));
                    myIsDrawing = false;
                    notifyClearButtonObservers();
                    repaint();
                }
            }
        };
    }

    public void undo() {
        if (!myShapes.isEmpty()) {
            myShapes.remove(myShapes.size() - 1);
            repaint();
            notifyUndoButtonState();
        }
    }

    public boolean canUndo() {
        return !myShapes.isEmpty();
    }

    private void notifyUndoButtonState() {
        for (Consumer<Boolean> observer : myClearObservers) {
            observer.accept(canUndo());
        }
    }

    public void addUndoButtonObserver(final Consumer<Boolean> theObserver) {
        myClearObservers.add(theObserver);
    }

    @Override
    protected void paintComponent(final Graphics theG) {
        super.paintComponent(theG);
        final Graphics2D g2d = (Graphics2D) theG;

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw existing shapes
        if (!myShapes.isEmpty()) {
            for (ShapeData data : myShapes) {
                g2d.setColor(data.getColor());
                g2d.setStroke(new BasicStroke(data.getStroke()));
                g2d.draw(data.getShape());
            }
        }

        // Draw current tool preview
        if (myCurrentTool != null && myIsDrawing) {
            g2d.setColor(myCurrentColor);
            g2d.setStroke(new BasicStroke(myStrokeWidth));
            final Shape shape = myCurrentTool.getShape();
            if (shape != null) {
                g2d.draw(myCurrentTool.getShape());
            }
        }
    }

    public List<ShapeData> getShapes() {
        return myShapes;
    }
}
