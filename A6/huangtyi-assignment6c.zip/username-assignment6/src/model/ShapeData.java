package model;

import java.awt.Color;
import java.awt.Shape;

public class ShapeData {
    /**
     * shape.
     */
    private Shape myShape;
    
    /**
     * color.
     */
    private Color myColor;
    
    /**
     * stroke.
     */
    private float myStroke;

    public ShapeData(final Shape theShape, final Color theColor, final float theStroke) {
        this.myShape = theShape;
        this.myColor = theColor;
        this.myStroke = theStroke;
    }

    public Shape getShape() {
        return myShape;
    }

    public Color getColor() {
        return myColor;
    }

    public float getStroke() {
        return myStroke;
    }
}
