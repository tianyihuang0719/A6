package model;

import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.GeneralPath;

public class PencilTool implements Tool {
    /**
     * general path.
     */
    private final GeneralPath myPath = new GeneralPath();

    @Override
    public void start(final Point thePoint) {
        if (thePoint != null) {
            myPath.reset();
            myPath.moveTo(thePoint.x, thePoint.y);
        }
    }

    @Override
    public void drag(final Point thePoint) {
        if (thePoint != null) {
            myPath.lineTo(thePoint.x, thePoint.y);
        }
    }

    @Override
    public Shape getShape() {
        return new GeneralPath(myPath);
    }
}
