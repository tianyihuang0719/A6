package model;

import java.awt.Point;
import java.awt.Shape;

public interface Tool {
    void start(Point thePoint);

    void drag(Point thePoint);

    Shape getShape();
}
