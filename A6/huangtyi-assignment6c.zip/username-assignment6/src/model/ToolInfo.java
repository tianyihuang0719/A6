package model;

import javax.swing.Icon;

public class ToolInfo {
    /**
     * name.
     */
    private String myName;
    
    /**
     * tool.
     */
    private Tool myTool;
    
    /**
     * icon.
     */
    private Icon myIcon;

    public ToolInfo(final String theName, final Tool theTool, final Icon theIcon) {
        this.myName = theName;
        this.myTool = theTool;
        this.myIcon = theIcon;
    }

    public String getName() {
        return myName;
    }

    public Tool getTool() {
        return myTool;
    }

    public Icon getIcon() {
        return myIcon;
    }
}
