package model;

import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;

public class RectangleTool implements Tool {
    /**
     * start point.
     */
    private Point myStartPoint;
    
    /**
     * end point.
     */
    private Point myEndPoint;

    @Override
    public void start(final Point thePoint) {
        if (thePoint != null) {
            myStartPoint = thePoint;
            myEndPoint = thePoint;
        }
    }

    @Override
    public void drag(final Point thePoint) {
        if (thePoint != null) {
            myEndPoint = thePoint;
        }
    }

    @Override
    public Shape getShape() {
        if (myStartPoint == null || myEndPoint == null) {
            return null;
        }

        return new Rectangle2D.Float(
                Math.min(myStartPoint.x, myEndPoint.x),
                Math.min(myStartPoint.y, myEndPoint.y),
                Math.abs(myEndPoint.x - myStartPoint.x),
                Math.abs(myEndPoint.y - myStartPoint.y)
        );
    }
}
