package model;

import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.Line2D;

public class LineTool implements Tool {
    /**
     * start point.
     */
    private Point myStartPoint;
    
    /**
     * end point.
     */
    private Point myEndPoint;

    @Override
    public void start(final Point thePoint) {
        if (thePoint != null) {
            myStartPoint = thePoint;
            myEndPoint = thePoint;
        }
    }

    @Override
    public void drag(final Point thePoint) {
        if (thePoint != null) {
            myEndPoint = thePoint;
        }
    }

    @Override
    public Shape getShape() {
        if (myStartPoint == null || myEndPoint == null) {
            return new Line2D.Float(0, 0, 0, 0);
        }
        return new Line2D.Float(myStartPoint, myEndPoint);
    }
}
