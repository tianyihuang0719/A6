/*
 * TCSS 305 - Assignment 5
 */

// Finish and comment me!

package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JSlider;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import model.EllipseTool;
import model.LineTool;
import model.PencilTool;
import model.RectangleTool;
import model.ToolInfo;
import controller.ToolAction;

/**
 * Presents the GUI for the PowerPaint application.
 * 
 * @author Alan Fowler (acfowler@uw.edu)
 * @author Tianyi Huang
 * @version Autumn 2024
 */
public final class PaintGUI {
    /**
     * title of frame.
     */
    private static final String TITLE = "TCSS 305 Paint";
    
    /**
     * title of select color.
     */
    private static final String TITLE_SELECT_COLOR = "Choose a Color";
    
    /**
     * tool name.
     */
    private static final String NAME_TOOL = "Tools";
    
    /**
     * color of r.
     */
    private static final int COLOR_R = 89;
    
    /**
     * color of g.
     */
    private static final int COLOR_G = 51;
    
    /**
     * color of b.
     */
    private static final int COLOR_B = 255;
    
    
    /**
     * major tick space.
     */
    private static final int MAJOR_TICK_SPACE = 5;
    
    /**
     * minor tick space.
     */
    private static final int MINOR_TICK_SPACE = 1;
    
    /**
     * name of line.
     */
    private static final String NAME_LINE = "Line";
    
    /**
     * name of rectangle.
     */
    private static final String NAME_RECTANGLE = "Rectangle";
    
    /**
     * name of ellipse.
     */
    private static final String NAME_ELLIPSE = "Ellipse";
    
    /**
     * name of pencil.
     */
    private static final String NAME_PENCIL = "Pencil";
    
    /**
     * title icon.
     */
    private static final String ICON_TITLE = "files/w_small.png";
    
    /**
     * ellipse icon.
     */
    private static final String ICON_ELLIPSE = "files/ellipse_bw.gif";
    
    /**
     * line icon.
     */
    private static final String ICON_LINE = "files/line_bw.gif";
    
    /**
     * pencil icon.
     */
    private static final String ICON_PENCIL = "files/pencil_bw.gif";
    
    /**
     * rectangle icon.
     */
    private static final String ICON_RECTANGLE = "files/rectangle_bw.gif";

    /**
     * drawing panel.
     */
    private DrawingPanel myDrawingPanel;
    
    /** The Window for this application. */
    private final JFrame myFrame;

    /**
     * Undo button.
     */
    private JButton myUndoButton;
    
    /**
     * tools.
     */
    private java.util.List<ToolInfo> myTools;
    
    /**
     * actions.
     */
    private Map<String, AbstractAction> myActions;
    
    /**
     * title icon.
     */
    private final ImageIcon myIconTitle;

    public PaintGUI() {
        super();
        myIconTitle = new ImageIcon(ICON_TITLE);
        myFrame = new JFrame(TITLE);
        myFrame.setIconImage(myIconTitle.getImage());
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        createComponents();
        
        start();
    }
    
    private void createComponents() {
        myDrawingPanel = new DrawingPanel();
        myFrame.add(myDrawingPanel, BorderLayout.CENTER);
        myDrawingPanel.setCurrentColor(new Color(COLOR_R, COLOR_G, COLOR_B));

        myTools = new ArrayList<>();
        initializeTools();
        myActions = new HashMap<>();
        initializeToolActions();

        final JMenuBar menuBar = new JMenuBar();
        myFrame.setJMenuBar(menuBar);

        setupOptionsMenu(menuBar);
        setupToolsMenu(menuBar);
        setupHelpMenu(menuBar);

        setupToolButtons();

        myActions.get(NAME_LINE).putValue(Action.SELECTED_KEY, Boolean.TRUE);
        myDrawingPanel.setCurrentTool(myTools.get(0).getTool());
    }

    private void initializeTools() {
        myTools.add(new ToolInfo(NAME_LINE, new LineTool(),
                new ImageIcon(ICON_LINE)));
        myTools.add(new ToolInfo(NAME_RECTANGLE, new RectangleTool(),
                new ImageIcon(ICON_RECTANGLE)));
        myTools.add(new ToolInfo(NAME_ELLIPSE, new EllipseTool(),
                new ImageIcon(ICON_ELLIPSE)));
        myTools.add(new ToolInfo(NAME_PENCIL, new PencilTool(),
                new ImageIcon(ICON_PENCIL)));
    }

    private void initializeToolActions() {
        for (ToolInfo toolInfo : myTools) {
            final ToolAction action = new ToolAction(toolInfo.getName(),
                    toolInfo.getTool(), myDrawingPanel);
            myActions.put(toolInfo.getName(), action);
        }
    }

    private void setupOptionsMenu(final JMenuBar theMenuBar) {
        final JMenu optionsMenu = new JMenu("Options");
        theMenuBar.add(optionsMenu);

        final JMenu thicknessMenu = new JMenu("Thickness");
        final JSlider thicknessSlider = new JSlider(0, 25, 5);
        thicknessSlider.setMajorTickSpacing(MAJOR_TICK_SPACE);
        thicknessSlider.setMinorTickSpacing(MINOR_TICK_SPACE);
        thicknessSlider.setPaintTicks(true);
        thicknessSlider.setPaintLabels(true);
        thicknessSlider.addChangeListener(e -> myDrawingPanel.setStrokeWidth(
                Math.max(thicknessSlider.getValue(), 1)));
        thicknessMenu.add(thicknessSlider);
        optionsMenu.add(thicknessMenu);

        optionsMenu.addSeparator();

        final JMenuItem colorItem = new JMenuItem("Color...");
        colorItem.addActionListener(e -> {
            final Color selectedColor = JColorChooser.showDialog(myFrame,
                    TITLE_SELECT_COLOR, myDrawingPanel.getCurrentColor());
            if (selectedColor != null) {
                myDrawingPanel.setCurrentColor(selectedColor);
            }
        });
        optionsMenu.add(colorItem);

        final JMenuItem backgroundItem = new JMenuItem("Background...");
        backgroundItem.addActionListener(e -> {
            final Color selectedColor = JColorChooser.showDialog(myFrame,
                    TITLE_SELECT_COLOR, myDrawingPanel.getCurrentColor());
            if (selectedColor != null) {
                myDrawingPanel.setBackground(selectedColor);
            }
        });
        optionsMenu.add(backgroundItem);

        optionsMenu.addSeparator();

        final JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> myDrawingPanel.clear());
        clearItem.setEnabled(!myDrawingPanel.getShapes().isEmpty());
        optionsMenu.add(clearItem);
        myDrawingPanel.addClearButtonObserver(enabled -> clearItem.setEnabled(enabled));
    }

    private void setupHelpMenu(final JMenuBar theMenuBar) {
        final JMenu helpMenu = new JMenu("Help");
        theMenuBar.add(helpMenu);

        final JMenuItem aboutItem = new JMenuItem("About...");
        aboutItem.addActionListener(e -> showAboutDialog());
        helpMenu.add(aboutItem);
    }

    private void showAboutDialog() {
        JOptionPane.showMessageDialog(
                myFrame,
                "Tianyi Huang\nAutumn 2024",
                TITLE,
                JOptionPane.INFORMATION_MESSAGE,
                myIconTitle);
    }

    private void setupToolsMenu(final JMenuBar theMenuBar) {
        final JMenu toolsMenu = new JMenu(NAME_TOOL);
        theMenuBar.add(toolsMenu);

        final ButtonGroup menuGroup = new ButtonGroup();
        for (ToolInfo toolInfo : myTools) {
            final AbstractAction action = myActions.get(toolInfo.getName());
            final JRadioButtonMenuItem menuItem = new JRadioButtonMenuItem(action);
            menuItem.setIcon(toolInfo.getIcon());
            toolsMenu.add(menuItem);
            menuGroup.add(menuItem);
        }
    }

    /**
     * Sets up tool buttons on the left panel.
     */
    private void setupToolButtons() {
        final JToolBar toolsToolBar = new JToolBar(NAME_TOOL, JToolBar.HORIZONTAL);
        toolsToolBar.setFloatable(true);
        myFrame.add(toolsToolBar, BorderLayout.SOUTH);

        myUndoButton = new JButton("Undo");
        myUndoButton.setEnabled(false);
        myUndoButton.addActionListener(e -> {
            myDrawingPanel.undo();
        });
        toolsToolBar.add(myUndoButton);
        toolsToolBar.addSeparator();

        for (ToolInfo toolInfo : myTools) {
            final AbstractAction action = myActions.get(toolInfo.getName());
            final JToggleButton button = new JToggleButton(action);
            button.setIcon(toolInfo.getIcon());
            toolsToolBar.add(button);
        }

        myDrawingPanel.addUndoButtonObserver(this::updateUndoButtonState);
    }

    private void updateUndoButtonState(final boolean theCanUndo) {
        myUndoButton.setEnabled(theCanUndo);
    }

    /**
     * Performs all tasks necessary to display the UI.
     */
    private void start() {
        final Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        final int screenWidth = screenSize.width;
        final int screenHeight = screenSize.height;
        final int width = screenWidth / 3;
        final int height = screenHeight / 3;
        myFrame.setSize(width, height);
        myFrame.setLocationRelativeTo(null);
        myFrame.setVisible(true);
    }

}
